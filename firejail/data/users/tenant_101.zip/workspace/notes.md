
# Table of Contents

1.  [Welcome to Emacs-Jail](#orgdada21b)
    1.  [Tasks](#orgc5eebfb)
        1.  [Review isolated org-mode capabilities](#org24bc16c)
        2.  [Test Org-Babel execution](#org70092ce)
    2.  [Python Babel Block Example](#orge5fca8a)



<a id="orgdada21b"></a>

# Welcome to Emacs-Jail

Your environment is sandboxed using Firejail and persisted in a single-file zip archive.


<a id="orgc5eebfb"></a>

## Tasks


<a id="org24bc16c"></a>

### TODO Review isolated org-mode capabilities


<a id="org70092ce"></a>

### TODO Test Org-Babel execution


<a id="orge5fca8a"></a>

## Python Babel Block Example

    print('Hello from sandboxed Python inside Emacs Org-mode!')

