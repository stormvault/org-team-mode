def square(n):
    """Return square of n."""
    return n * n

def factorial(n):
    """Return factorial of n."""
    if n <= 1:
        return 1
    return n * factorial(n - 1)

if __name__ == "__main__":
    print(f"5! = {factorial(5)}")
