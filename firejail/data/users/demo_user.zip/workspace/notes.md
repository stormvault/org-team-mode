
# Table of Contents

1.  [Welcome to Emacs-Jail](#orgacd1aa6)
    1.  [Tasks](#orgfecfb3c)
        1.  [Review isolated org-mode capabilities](#org90cd045)
        2.  [Test Org-Babel execution](#orgea268c3)
    2.  [Python Babel Block Example](#org495e065)



<a id="orgacd1aa6"></a>

# Welcome to Emacs-Jail

Your environment is sandboxed using Firejail and persisted in a single-file zip archive.


<a id="orgfecfb3c"></a>

## Tasks


<a id="org90cd045"></a>

### TODO Review isolated org-mode capabilities


<a id="orgea268c3"></a>

### TODO Test Org-Babel execution


<a id="org495e065"></a>

## Python Babel Block Example

    print('Hello from sandboxed Python inside Emacs Org-mode!')

